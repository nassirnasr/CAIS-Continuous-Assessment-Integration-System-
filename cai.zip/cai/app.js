const express = require('express');
const path = require('path');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Database connection configuration
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'cai',
});

// Connect to the database
db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err);
  } else {
    console.log('Connected to the database');
  }
});


app.set('views', path.join(__dirname, 'views'));


app.set('view engine', 'pug');


app.use(express.static(path.join(__dirname, 'public')));

// Routes

app.get('/about', (req, res) => {
  res.render('about');
});

app.get('/contact', (req, res) => {
  res.render('contact');
});

app.get('/login', (req, res) => {
  res.render('login');
});


app.post('/dashboard', (req, res) => {
  const { email, password } = req.body;

  // Check student's login credential
  const query = 'SELECT * FROM Students WHERE Email = ?';
  db.query(query, [email], (err, results) => {
    if (err) {
      console.error('Error querying the database:', err);
      res.render('login', { error: 'Internal Server Error' });
    } else {
      if (results.length > 0 && results[0].Email === email) {
        // Successful login
        res.render('dashboard', { user: results[0] });
      } else {
        // Invalid credentials
        res.render('login', { error: 'Invalid email or password' });
      }
    }
  });
});


app.post('/results', (req, res) => {
  const { email, password } = req.body;

  // Check student's login credential
  const query = 'SELECT * FROM Students WHERE Email = ?';
  db.query(query, [email], (err, results) => {
    if (err) {
      console.error('Error querying the database:', err);
      res.render('login', { error: 'Internal Server Error' });
    } else {
      if (results.length > 0 && results[0].Email === email) {
        // Fetch data from database
        const assessmentQuery = `
        SELECT
          Students.FirstName,
          Students.LastName,
          Students.Email,
          Students.DateOfBirth,
          Students.Gender,
          Students.ContactNumber,
          Students.Address,
          Students.Nationality,
          Enrollments.EnrollmentDate,
          Enrollments.EnrollmentStatus,
          Courses.CourseName,
          Courses.CourseCode,
          Courses.Department,
          Courses.Credits,
          
          Results.Test1,
          Results.Test2,
          Results.Assignment,
          Results.Practical
        FROM
          Students
        JOIN
          Enrollments ON Students.StudentID = Enrollments.StudentID
        JOIN
          Courses ON Enrollments.CourseID = Courses.CourseID
        JOIN
          Assessments ON Enrollments.CourseID = Assessments.CourseID
        JOIN
          Results ON Enrollments.EnrollmentID = Results.EnrollmentID
        WHERE
          Students.Email = ? AND Students.Password = ?;
      `;
      
        db.query(assessmentQuery, [email, password], (assessmentErr, assessmentResults) => {
          if (assessmentErr) {
            console.error('Error querying assessment results:', assessmentErr);
            res.render('login', { error: 'Internal Server Error' });
          } else {
            res.render('results', { user: assessmentResults[0], assessmentResults });
          }
        });
      } else {
        // Invalid credentials
        res.render('login', { error: 'Invalid email or password' });
      }
    }
  });
});


app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
